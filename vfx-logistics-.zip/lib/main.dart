import 'package:flutter/material.dart';
import 'package:flutterapp/vfx_20logistics_20app/generatedlogoartboard1copy41widget/GeneratedLogoArtboard1copy41Widget.dart';
import 'package:flutterapp/vfx_20logistics_20app/generatedgooglepixel21widget/GeneratedGooglePixel21Widget.dart';
import 'package:flutterapp/vfx_20logistics_20app/generatedgooglepixel22widget/GeneratedGooglePixel22Widget.dart';
import 'package:flutterapp/vfx_20logistics_20app/generatedgooglepixel25widget/GeneratedGooglePixel25Widget.dart';
import 'package:flutterapp/vfx_20logistics_20app/generatedgooglepixel27widget/GeneratedGooglePixel27Widget.dart';
import 'package:flutterapp/vfx_20logistics_20app/generatedgooglepixel28widget/GeneratedGooglePixel28Widget.dart';
import 'package:flutterapp/vfx_20logistics_20app/generated1200widget/Generated1200Widget.dart';
import 'package:flutterapp/vfx_20logistics_20app/generatedgooglepixel26widget/GeneratedGooglePixel26Widget.dart';
import 'package:flutterapp/vfx_20logistics_20app/generatedgooglepixel23widget/GeneratedGooglePixel23Widget.dart';
import 'package:flutterapp/vfx_20logistics_20app/generatedgooglepixel24widget/GeneratedGooglePixel24Widget.dart';
import 'package:flutterapp/vfx_20logistics_20app/generatediconwidget/GeneratedIconWidget.dart';
import 'package:flutterapp/vfx_20logistics_20app/generatedsplashwidget/GeneratedSplashWidget.dart';
import 'package:flutterapp/vfx_20logistics_20app/generatedlogowidget/GeneratedLogoWidget.dart';

void main() {
  runApp(vfx_20logistics_20App());
}

class vfx_20logistics_20App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedGooglePixel21Widget',
      routes: {
        '/GeneratedLogoArtboard1copy41Widget': (context) =>
            GeneratedLogoArtboard1copy41Widget(),
        '/GeneratedGooglePixel21Widget': (context) =>
            GeneratedGooglePixel21Widget(),
        '/GeneratedGooglePixel22Widget': (context) =>
            GeneratedGooglePixel22Widget(),
        '/GeneratedGooglePixel25Widget': (context) =>
            GeneratedGooglePixel25Widget(),
        '/GeneratedGooglePixel27Widget': (context) =>
            GeneratedGooglePixel27Widget(),
        '/GeneratedGooglePixel28Widget': (context) =>
            GeneratedGooglePixel28Widget(),
        '/Generated1200Widget': (context) => Generated1200Widget(),
        '/GeneratedGooglePixel26Widget': (context) =>
            GeneratedGooglePixel26Widget(),
        '/GeneratedGooglePixel23Widget': (context) =>
            GeneratedGooglePixel23Widget(),
        '/GeneratedGooglePixel24Widget': (context) =>
            GeneratedGooglePixel24Widget(),
        '/GeneratedIconWidget': (context) => GeneratedIconWidget(),
        '/GeneratedSplashWidget': (context) => GeneratedSplashWidget(),
        '/GeneratedLogoWidget': (context) => GeneratedLogoWidget(),
      },
    );
  }
}
